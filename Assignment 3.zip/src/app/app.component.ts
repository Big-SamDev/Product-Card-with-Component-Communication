import { Component } from '@angular/core';
import { NavbarComponent } from './navbar/navbar.component';
import { ProductCardComponent } from './product-card/product-card.component';
import { Product } from './product.interface';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NavbarComponent, ProductCardComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  searchQuery: string = '';
  cartCount: number = 0;
  selectedProductIds: number[] = [];

  products: Product[] = [
    { id: 1, name: 'Classic White T-Shirt', description: 'Soft cotton everyday basic', price: 19.99, img src: 'classic-white-tshirt' },
    { id: 2, name: 'Denim Jacket', description: 'Timeless style with distressed details', price: 79.99, img src: 'denim-jacket' },
    { id: 3, name: 'Black Hoodie', description: 'Cozy fleece-lined comfort', price: 49.99, imageUrl: 'black-hoodie' },
    { id: 4, name: 'Floral Summer Dress', description: 'Light and breezy for warm days', price: 59.99, imageUrl: 'floral dress' },
    { id: 5, name: 'Leather Boots', description: 'Premium leather built to last', price: 129.99, imageUrl: 'leather-boots' },
    { id: 6, name: 'Striped Polo Shirt', description: 'Smart casual perfection', price: 39.99, imageUrl: 'striped-polo-shirt' }
  ];

  filteredProducts: Product[] = [...this.products];

  onSearch(query: string) {
    this.searchQuery = query;
    this.filterProducts();
  }

  onProductClick(product: Product) {
    if (!this.selectedProductIds.includes(product.id)) {
      this.selectedProductIds.push(product.id);
      this.cartCount++;
    }
  }

  private filterProducts() {
    if (!this.searchQuery.trim()) {
      this.filteredProducts = [...this.products];
    } else {
      const query = this.searchQuery.toLowerCase();
      this.filteredProducts = this.products.filter(p =>
        p.name.toLowerCase().includes(query)
      );
    }
  }
}