import { Component } from '@angular/core';
import { NavbarComponent } from './navbar/navbar.component';
import { ProductCardComponent } from './product-card/product-card.component';
import { Product } from './product.interface';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NavbarComponent, ProductCardComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  searchQuery: string = '';
  cartCount: number = 0;
  selectedProductIds: number[] = [];

  products: Product[] = [
    { id: 1, name: 'Classic White T-Shirt', description: 'Soft cotton everyday basic', price: 19.99, imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBikM-cVi5hPRMn3lf0DBCxxQZAz-j51OIjw&s' },
    { id: 2, name: 'Denim Jacket', description: 'Timeless style with distressed details', price: 79.99, imageUrl:"https://cdn-images.farfetch-contents.com/24/50/80/50/24508050_54930144_600.jpg"},
    { id: 3, name: 'Black Hoodie', description: 'Cozy fleece-lined comfort', price: 49.99, imageUrl: 'https://www.shutterstock.com/image-photo/template-black-oversized-hoodie-unfolded-600nw-2489688971.jpg'},
    { id: 4, name: 'Floral Summer Dress', description: 'Light and breezy for warm days', price: 59.99, imageUrl: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTVpja4vevxFhtivdECPLQtj3IdUOeylfQ8K6tVYvl4IjfEEblfw5Jv7VUw8HAxNXn8rQvF1-7huUH7qXsplBMSaz9kuL_RW8cpgPrX1dMayI54MGgdpGYgWoURW9rEw1mPSJvJ5A&usqp=CAc' },
    { id: 5, name: 'Leather Boots', description: 'Premium leather built to last', price: 129.99, imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTeAbTQysRnFZyPCAwtis5a2-xdT-bwujz6dA&s' },
    { id: 6, name: 'Striped Polo Shirt', description: 'Smart casual perfection', price: 39.99, imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZRo7dez3t1aZYxy7_FdfUTinwXEg4FKx2AA&s' }
  ];

  filteredProducts: Product[] = [...this.products];

  onSearch(query: string) {
    this.searchQuery = query;
    this.filterProducts();
  }

  onProductClick(product: Product) {
  const id = product.id;
  const index = this.selectedProductIds.indexOf(id);

  if (index === -1) {
    // Not in cart → add it
    this.selectedProductIds.push(id);
    this.cartCount++;
  } else {
    // Already in cart → remove it
    this.selectedProductIds.splice(index, 1);  // Remove specific item
    this.cartCount--;
  }
}

  private filterProducts() {
    if (!this.searchQuery.trim()) {
      this.filteredProducts = [...this.products];
    } else {
      const query = this.searchQuery.toLowerCase();
      this.filteredProducts = this.products.filter(p =>
        p.name.toLowerCase().includes(query)
      );
    }
  }
}