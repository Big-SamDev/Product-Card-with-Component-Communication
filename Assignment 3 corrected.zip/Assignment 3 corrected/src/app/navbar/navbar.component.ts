import { Component, Input, Output, EventEmitter } from '@angular/core';
import { SearchInputComponent } from '../search-input/search-input.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [SearchInputComponent],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  @Input() cartCount: number = 0;
  @Output() search = new EventEmitter<string>();

  onSearchQuery(query: string) {
    this.search.emit(query);
  }
}