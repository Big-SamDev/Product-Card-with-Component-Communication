
import { Component, inject } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProductService } from '../../services/product';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-new',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './new.html',
  styleUrls: ['./new.css']
})
export class NewProductComponent {
  private fb = inject(FormBuilder);
  private productService = inject(ProductService);
  private router = inject(Router);

  productForm: FormGroup;

  constructor() {
    this.productForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
      price: [null, [Validators.required, Validators.min(50)]],
      category: ['', Validators.required],
      imageUrl: ['', [Validators.required, Validators.pattern(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)]],
      inStock: [true],
      rating: [0, [Validators.required, Validators.min(0), Validators.max(5)]],
      properties: this.fb.array([
        this.createPropertyGroup()
      ], Validators.required)
    });
  }

  get properties(): FormArray {
    return this.productForm.get('properties') as FormArray;
  }

  createPropertyGroup(): FormGroup {
    return this.fb.group({
      color: ['', Validators.required],
      weight: [null, [Validators.required, Validators.min(0.1)]]
    });
  }

  addProperty() {
    this.properties.push(this.createPropertyGroup());
  }

  removeProperty(index: number) {
    if (this.properties.length > 1) {
      this.properties.removeAt(index);
    }
  }

  get name()         { return this.productForm.get('name'); }
  get description()  { return this.productForm.get('description'); }
  get price()        { return this.productForm.get('price'); }
  get category()     { return this.productForm.get('category'); }
  get imageUrl()     { return this.productForm.get('imageUrl'); }
  get rating()       { return this.productForm.get('rating'); }

  onSubmit() {
    if (this.productForm.invalid) return;

    const formValue = this.productForm.value;

    const newProduct = {
      ...formValue,
      properties: formValue.properties   // send array of {color, weight}
    };

    this.productService.createProduct(newProduct).subscribe({
      next: (created) => {
        alert('Product created successfully! ID: ' + created.id);
        this.productForm.reset();
        this.properties.clear();
        this.properties.push(this.createPropertyGroup());
        this.router.navigate(['/products']);
      },
      error: (err) => {
        alert('Error creating product: ' + err.message);
      }
    });
  }

  getErrorMessage(controlName: string): string {
    const control = this.productForm.get(controlName);
    if (!control || !control.errors || !control.touched) return '';

    if (control.errors['required']) return 'This field is required';
    if (control.errors['minlength']) return `Minimum length: ${control.errors['minlength'].requiredLength}`;
    if (control.errors['min']) return `Minimum value: ${control.errors['min'].min}`;
    if (control.errors['max']) return `Maximum value: ${control.errors['max'].max}`;
    if (control.errors['pattern']) return 'Invalid URL format (must end with .jpg|.png|...)';

    return 'Invalid value';
  }
}