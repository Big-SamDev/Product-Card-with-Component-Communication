import { Component, inject } from '@angular/core';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterOutlet } from '@angular/router';
import { ProductService } from './services/product';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NavbarComponent, RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private productService = inject(ProductService);
  cartCount = 0;
  onSearch(query: string) {
    console.log('Search query:', query);
  }

  ngOnInit() {
    this.productService.cartIds$.subscribe(ids => {
      this.cartCount = ids.length;
    });
  }
}