import { Component, inject } from '@angular/core';
import { ProductService } from '../services/product';
import { Product } from '../product.interface';
import { CommonModule } from '@angular/common';
import { ProductCardComponent } from '../product-card/product-card.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, ProductCardComponent, RouterLink],
  templateUrl: './product-list.html',
  styleUrls: ['./product-list.css']
})
export class ProductListComponent {
  private productService = inject(ProductService);
  products: Product[] = [];
  filteredProducts: Product[] = [];

  ngOnInit() {
    this.productService.getAllProducts().subscribe(data => {
      this.products = data;
      this.filteredProducts = [...data];
    });
  }

  toggleCart(product: Product) {
    if (this.productService.isInCart(product.id)) {
      this.productService.removeFromCart(product.id);
    } else {
      this.productService.addToCart(product.id);
    }
  }

  isSelected(id: number): boolean {
    return this.productService.isInCart(id);
  }
}