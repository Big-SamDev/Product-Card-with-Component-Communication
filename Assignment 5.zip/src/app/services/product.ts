import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Product } from '../product.interface';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:3000/products';

  createProduct(product: Omit<Product, 'id'>): Observable<Product> {
    return this.http.post<Product>(this.apiUrl, product);
  }

  // Cart state (shared across components)
  private cartIds = new BehaviorSubject<number[]>([]);
  cartIds$ = this.cartIds.asObservable();

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  getProductById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  addToCart(id: number) {
    const current = this.cartIds.value;
    if (!current.includes(id)) {
      this.cartIds.next([...current, id]);
    }
  }

  removeFromCart(id: number) {
    const current = this.cartIds.value.filter(cid => cid !== id);
    this.cartIds.next(current);
  }

  isInCart(id: number): boolean {
    return this.cartIds.value.includes(id);
  }
}