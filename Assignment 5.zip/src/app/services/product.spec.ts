import { Product } from '../product-card/product.interface';

describe('Product interface shape', () => {
  it('should support valid product data', () => {
    const product: Product = {
      id: 1,
      name: 'Test Product',
      description: 'Description',
      price: 99.99,
      imageUrl: '/assets/test.jpg',
      category: 'Test',
      inStock: true,
      rating: 4.5
    };

    expect(product.id).toBe(1);
    expect(product.name).toBe('Test Product');
    expect(product.price).toBe(99.99);
    expect(product.inStock).toBe(true);
    expect(product.rating).toBe(4.5);
  });
});
