import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Product } from '../product.interface';


@Component({
  selector: 'app-product-card',
  standalone: true,
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})

export class ProductCardComponent {
  @Input() product!: Product;
  @Input() isSelected: boolean = false;
  @Output() productSelected = new EventEmitter<Product>();

  onCardClick() {
    this.productSelected.emit(this.product);
  }
}