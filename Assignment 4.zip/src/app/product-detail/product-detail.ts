import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../services/product';
import { Product } from '../product.interface';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-detail.html',
  styleUrls: ['./product-detail.css']
})
export class ProductDetail {
  private route = inject(ActivatedRoute);
  public productService = inject(ProductService);

  product?: Product;
  categoryFromQuery?: string;

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.categoryFromQuery = this.route.snapshot.queryParamMap.get('category') || 'Unknown';

    this.productService.getProductById(id).subscribe(data => {
      this.product = data;
    });
  }

  toggleCart() {
    if (this.product) {
      if (this.productService.isInCart(this.product.id)) {
        this.productService.removeFromCart(this.product.id);
      } else {
        this.productService.addToCart(this.product.id);
      }
    }
  }
}