import { Component, inject } from '@angular/core';
import { ProductService } from '../services/product';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart.html',
  styleUrls: ['./cart.css']
})
export class CartComponent {
  private productService = inject(ProductService);
  cartIds: number[] = [];
  cartNames: string[] = [];

  ngOnInit() {
    this.productService.cartIds$.subscribe(ids => {
      this.cartIds = ids;
     
      this.cartNames = ids.map(id => `Product #${id}`);
    });
  }
}