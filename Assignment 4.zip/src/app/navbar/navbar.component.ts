import { Component, Input,} from '@angular/core';
import { RouterLink } from '@angular/router';
import { SearchInputComponent } from '../search-input/search-input.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [
    RouterLink,
    SearchInputComponent
  ],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  @Input() cartCount: number = 0;

onSearchQuery(query: string) {
  console.log('Search query from navbar:', query);
  
}

}